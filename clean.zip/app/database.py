# Geçici bellek – ileride DB eklenecek
url_db = {}
